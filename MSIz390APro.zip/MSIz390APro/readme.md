SMBIOS Values have been redacted
EFI was generated using OC-Gen-X
Credit to /u/nobbylobo on reddit for helping with graphics acceleration!!
Installer Created Using BalenaEtcher With Catalina image.raw
